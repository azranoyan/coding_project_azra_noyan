python3 read_and_print.py data/IT_products.csv

